1. 完成上课代码
	1)使用if分支语句实现星期判断功能
	2)使用switch分支语句实现星期判断功能
	3)使用for,while,dowhile循环实现1~100之间的累加功能
	
2. 使用for while do-while双重for循环实现99乘法表前两种
	

